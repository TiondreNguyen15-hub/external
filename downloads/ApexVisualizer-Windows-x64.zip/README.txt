Apex Visualizer - Windows x64

Extract all files, then double-click apex_visualizer.exe.
Requires Windows 10/11 x64 and Direct3D 11.

This application displays SAMPLE PLAYERS ONLY. It does not connect to Apex.
Build verified by cross-compilation; Windows runtime behavior is untested.

Built from source commit 8e3f337dd59737aa790428d6d4d0a5ebe18171af
with llvm-mingw 20261104 UCRT, C++17, -O2, static runtime.
Dear ImGui v1.91.8 (dbb5eeaadffb6a3ba6a60de1290312e5802dba5a).
